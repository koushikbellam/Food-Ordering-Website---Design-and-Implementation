// Home Page Component
function HomePage({ navigate }) {
  return (
    <>
      <section className="hero">
        <div className="hero-content">
          <h1 className="hero-title">Delicious Food<br />Delivered Fast</h1>
          <p className="hero-subtitle">Order your favorite meals from local restaurants and enjoy them at home.</p>
          <button className="btn btn-primary" onClick={() => navigate('booking')}>Order Now</button>
        </div>
      </section>
      
      <h2>Featured Meals</h2>
      <div className="featured">
        <div className="food-card">
          <div className="food-image">Food Image</div>
          <div className="food-details">
            <h3 className="food-title">Margherita Pizza</h3>
            <p className="food-price">$12.99</p>
            <button className="btn btn-primary" onClick={() => navigate('booking')}>Order Now</button>
          </div>
        </div>
        <div className="food-card">
          <div className="food-image">Food Image</div>
          <div className="food-details">
            <h3 className="food-title">Chicken Burger</h3>
            <p className="food-price">$8.99</p>
            <button className="btn btn-primary" onClick={() => navigate('booking')}>Order Now</button>
          </div>
        </div>
        <div className="food-card">
          <div className="food-image">Food Image</div>
          <div className="food-details">
            <h3 className="food-title">Pasta Carbonara</h3>
            <p className="food-price">$10.99</p>
            <button className="btn btn-primary" onClick={() => navigate('booking')}>Order Now</button>
          </div>
        </div>
      </div>
    </>
  );
}

// Sign In Page Component
function SignInPage({ navigate, onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin({ name: 'User', email: email });
  };
  
  return (
    <div className="form-container">
      <h2 className="form-title">Sign In</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input 
            type="email" 
            className="form-control" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input 
            type="password" 
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary" style={{width: '100%'}}>Sign In</button>
      </form>
      <p style={{marginTop: '20px', textAlign: 'center'}}>
        Don't have an account? <a href="#" onClick={(e) => { e.preventDefault(); navigate('signup'); }}>Sign Up</a>
      </p>
    </div>
  );
}

// Sign Up Page Component
function SignUpPage({ navigate, onLogin }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onLogin({ name: name, email: email });
  };
  
  return (
    <div className="form-container">
      <h2 className="form-title">Create Account</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Name</label>
          <input 
            type="text" 
            className="form-control"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input 
            type="email" 
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input 
            type="password" 
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary" style={{width: '100%'}}>Sign Up</button>
      </form>
      <p style={{marginTop: '20px', textAlign: 'center'}}>
        Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); navigate('signin'); }}>Sign In</a>
      </p>
    </div>
  );
}

// Booking Page Component
function BookingPage({ navigate }) {
  const [address, setAddress] = useState('');
  const [selectedItems, setSelectedItems] = useState([
    { id: 1, name: 'Margherita Pizza', price: 12.99, quantity: 1 }
  ]);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Order placed, navigating to confirmation");
    navigate('confirmation');
  };
  
  return (
    <div className="form-container" style={{maxWidth: '600px'}}>
      <h2 className="form-title">Complete Your Order</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Delivery Address</label>
          <input 
            type="text" 
            className="form-control"
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            required
          />
        </div>
        
        <div className="form-group">
          <h3>Order Summary</h3>
          {selectedItems.map(item => (
            <div key={item.id} style={{display: 'flex', justifyContent: 'space-between', marginBottom: '10px'}}>
              <span>{item.name} x {item.quantity}</span>
              <span>${(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
          <div style={{borderTop: '1px solid #ddd', paddingTop: '10px', display: 'flex', justifyContent: 'space-between'}}>
            <strong>Total</strong>
            <strong>${selectedItems.reduce((sum, item) => sum + (item.price * item.quantity), 0).toFixed(2)}</strong>
          </div>
        </div>
        
        <div className="form-group">
          <label className="form-label">Payment Method</label>
          <select className="form-control">
            <option>Credit Card</option>
            <option>Cash on Delivery</option>
          </select>
        </div>
        
        <button type="submit" className="btn btn-primary" style={{width: '100%'}}>Place Order</button>
      </form>
    </div>
  );
}

// Confirmation Page Component
function ConfirmationPage({ navigate }) {
  return (
    <div className="form-container success-message">
      <h2 className="form-title">Order Confirmed!</h2>
      <p style={{marginBottom: '20px'}}>Your order has been placed successfully. You will receive a confirmation email shortly.</p>
      <p style={{marginBottom: '20px'}}>Estimated delivery time: 30-45 minutes</p>
      <button className="btn btn-primary" onClick={() => navigate('home')}>Back to Home</button>
    </div>
  );
}